from django.apps import AppConfig


class RankingsConfig(AppConfig):
    name = 'rankings'
