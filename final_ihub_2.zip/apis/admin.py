from django.contrib import admin
from .models import Api

# Register your models here.
admin.site.register(Api)